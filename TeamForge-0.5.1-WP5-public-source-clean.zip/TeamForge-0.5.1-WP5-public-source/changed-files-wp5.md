# Changed Files — TeamForge 0.5.1 WP5 Diagnostics & Recovery UX

Baseline: exact immutable `Unity-TeamForge-0.5.1-WP4.1-guest-refresh-rejoin-hotfix-win-x64.zip`.

## Product source and tests

- `project-peer/src/bootstrap-invite.mjs`
- `project-peer/src/coordinator-client.mjs`
- `project-peer/src/guest-orchestrator.mjs`
- `project-peer/src/guest-orchestrator-cli.mjs`
- `project-peer/test/guest-bridge.test.mjs`
- `project-peer/test/wp5-diagnostics-recovery.test.mjs`
- `launcher/src/TeamForge.Launcher.Core/BridgeClient.cs`
- `launcher/src/TeamForge.Launcher.Core/DiagnosticsRecovery.cs`
- `launcher/src/TeamForge.Launcher.Core/RuntimeLayout.cs`
- `launcher/src/TeamForge.Launcher.Core/UnityLaunchPolicy.cs`
- `launcher/src/TeamForge.Launcher/MainWindow.xaml`
- `launcher/src/TeamForge.Launcher/MainWindow.xaml.cs`
- `launcher/tests/TeamForge.Launcher.Core.Tests/Program.cs`
- `unity-package/com.eunsung.teamforge/Editor/UX/TeamForgeBaselineFingerprint.cs`
- `unity-package/com.eunsung.teamforge/Editor/UX/TeamForgeHomeWindow.cs`
- `unity-package/com.eunsung.teamforge/Editor/UX/TeamForgeHostFlow.cs`
- `unity-package/com.eunsung.teamforge/Editor/UX/TeamForgeJoinCode.cs`
- `unity-package/com.eunsung.teamforge/Editor/UX/TeamForgeQuickStartUtility.cs`
- `unity-package/com.eunsung.teamforge/Editor/UX/TeamForgeRecoveryUx.cs`
- `unity-package/com.eunsung.teamforge/Editor/UX/TeamForgeRecoveryUx.cs.meta`
- `unity-package/com.eunsung.teamforge/Tests/Editor/TeamForgeUxTests.cs`

## Release contract, validation, and current documentation

- `release-contract.json`
- `scripts/stage-wp4-release.mjs`
- `scripts/validate-repository.mjs`
- `scripts/verify-wp4-archive.ps1`
- `README.md`
- `docs/project-state.md`
- `docs/known-issues.md`
- `docs/roadmap.md`
- `WP5-Diagnostics-Recovery-UX-Report.md`
- `Windows-Field-Test-Checklist-WP5.md`
- `executable-smoke-results-wp5.md`
- `changed-files-wp5.md`

## Generated release artifacts

The following are regenerated from the listed canonical source and exact pinned
toolchain after source freeze; they are not hand-edited:

- `unity-package/com.eunsung.teamforge/Runtime~/**`
- `unity-package/com.eunsung.teamforge/Editor/UX/TeamForgeRuntimeManifest.g.cs`
- `launcher/src/TeamForge.Launcher/RuntimePins.g.cs`
- `launcher/win-x64/**`
- `release-manifest.json` in the staged candidate

No Protocol v1 schema, authority, Project UUID/Owner/Publisher trust tuple,
manifest hashing, signed Invite validation, or atomic Active invariant is
intentionally changed.
