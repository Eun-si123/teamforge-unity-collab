# WP4.1 Existing Guest Refresh / Rejoin Hotfix Report — TeamForge 0.5.1

Status: **AUTOMATED SOURCE REGRESSION PASS / FIELD BLOCKED**

The tester reported that the prior exact WP4 fresh-Guest Windows field path
succeeded through Collaboration Invite, LAN endpoint, access code, Project
Transfer, verification, atomic Active activation, and Unity open. That prior
field evidence is retained as a prerequisite; it is not presented as a new
WP4.1 execution.

## Field blocker and repair

The stored signed Project Invite was previously compared by exact JSON bytes.
A legitimate new session changed signed session/endpoint fields and therefore
failed as `invite_conflict`, even when Project UUID and Owner were unchanged.

WP4.1 now:

- validates every newly supplied Project and bootstrap Invite signature;
- permits atomic replacement of stored invite metadata only for the same
  Project UUID, Project ID, and pinned Owner key;
- rejects changed Project UUID, changed Owner, and tampered Invite before the
  stored binding changes;
- preserves the existing `{projectUuid, ownerKeyId, publisherKeyId}` trust pin;
- routes a changed Publisher through the existing explicit trust challenge;
- never changes an Active directory or `current.json` merely by importing an
  Invite.

The successful Baseline path remains download/staging, complete hash/signature
and Unity-project verification, optional Publisher approval, immutable new
Active directory, then atomic current-pointer replacement. A failed rev2
transfer retains failure staging and leaves the verified rev1 Active/current
pointer untouched. Stale Scene mismatch rejection is unchanged; WP4.1 does not
connect a stale Scene directly as a bypass.

## Automated regression evidence

Focused WP4.1 tests: **5/5 PASS**.

- rev1 Fresh Guest → Host restart → same Baseline/new session → same managed
  root rejoin, same Active and unchanged current pointer;
- rev1 → source change → rev2 → new signed Invite → verified immutable rev2
  Active and new Unity handoff, with rev1 still present;
- changed Project UUID, changed Owner, and tampered Invite fail closed;
- changed Publisher cannot activate without explicit trust; decline preserves
  rev1 and later approval activates rev2;
- failed rev2 chunk transfer retains failure staging and preserves rev1.

The full Project Peer suite passed **129/129** and syntax checked **64** modules
after both locked `ws` installations were prepared. Remaining release,
Runtime, Launcher, Server, archive, fresh-extraction, and Unity evidence is
recorded in `Release-Integrity-Audit.md` and `executable-smoke-results.md`.

## Preserved scope boundaries

Realtime Protocol v1, Project Transfer Protocol v1, Manifest Schema v1,
Authority, Owner/Publisher signatures, direct HTTP payload transfer, trust
pins, content hashes, immutable Active revisions, and atomic activation remain
unchanged. WebRTC, ICE/STUN/TURN, relay, discovery, NAT traversal, and arbitrary
component/serialized-property synchronization are outside this hotfix.

## Field status

The WP4.1 existing-Guest two-PC Windows checklist is **NOT RUN manually** on
the new immutable candidate. WP4.1 remains **FIELD BLOCKED / NOT COMPLETED**
until every required item in `Windows-Field-Test-Checklist-WP4-Hotfix.md`
passes against that exact ZIP.
