# TeamForge 0.5.1 WP5 Diagnostics & Recovery UX Report

Status: **FIELD BLOCKED**

WP5 adds beginner-facing failure cards, stable error codes, state-driven safe
actions, and an Advanced / Technical Details surface to the existing 0.5.1
WP4.1 Guest Refresh candidate. It does not change Protocol v1, authority,
signed Invite/trust policy, direct HTTP project transfer, hash verification, or
immutable atomic Active activation.

## Implemented behavior

- The default Host and Guest screens show a short title, plain-language reason,
  stable code, and only actions supported by inspected state.
- Advanced / Technical Details can copy a bounded current-run diagnostic bundle
  with product/runtime/Unity identity, role, operation, stable code, shortened
  Project identity, revision/Active state, managed root, endpoint, process
  ownership, health, transfer/staging/runtime stage, and prior-Active state.
- Access codes, authentication tokens, Authorization values, private keys, and
  caller-supplied secret values are redacted. The history is memory-only and
  bounded to 32 events.
- A failed receive can offer the previous verified Active for offline Unity open
  only after C# containment, reparse-point, Active-shape, ProjectVersion, and
  Unity-project checks. This does not connect a stale Scene to realtime and does
  not create or reuse a session handoff.
- Runtime integrity failures retain the exact verification stage. Windows path
  headroom is checked before receive/open. Unknown port owners are never killed.
- A 0.5.0 runtime receiving a 0.5.1 signed Invite reports an explicit TeamForge
  version mismatch instead of a generic incompatible-invite message.

## Preserved boundaries

- Every new Invite signature and signed Project Transfer invite is revalidated.
- Project UUID or pinned Owner change hard-fails; Publisher changes retain the
  explicit `{projectUuid, ownerKeyId, publisherKeyId}` trust flow.
- Tampered invites hard-fail without deleting or replacing a verified Active.
- New Baselines remain staging -> complete verification -> immutable new Active
  -> atomic current pointer. Failed transfer leaves the previous Active current.
- Scene baseline mismatch remains fail-closed. No action bypasses that check.
- Arbitrary Component/serialized-property synchronization remains a Known
  Limitation and is outside WP5.
- Persistent recovery, WebRTC/ICE/STUN/TURN/relay/NAT/discovery, Host Migration,
  Protocol v2, and new authority semantics are outside WP5.

## Automated evidence

- Project Peer full suite: **134/134 PASS**.
- Project Peer WP5 focused suite: **5/5 PASS**.
- Server full suite: **72/72 PASS**.
- Launcher Core: **24/24 PASS**.
- Launcher WPF Release build: **PASS, 0 warnings, 0 errors**.
- Unity 6000.3.21f1 EditMode: **NOT RUN**. Unity loaded and performed a domain
  reload, but licensing IPC timed out and no result XML was produced. The log
  is preserved; this is not a test PASS.
- Manual WP5 Windows field checklist: **NOT RUN**.
- Formal two-PC WP4.1 closure: **DEFERRED / FIELD BLOCKED**.

The exact final archive, fresh-extraction, Runtime, Launcher, archive-adversarial,
and executable smoke results are recorded after release freeze in the adjacent
final verification and smoke reports. Until those gates and the manual field
check are completed, this report must not be read as WP5 or WP4.1 closure.
