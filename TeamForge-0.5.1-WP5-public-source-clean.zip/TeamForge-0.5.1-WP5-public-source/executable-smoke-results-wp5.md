# Executable Smoke Results — TeamForge 0.5.1 WP5

Status: **STAGED EXECUTABLE PASS; FINAL ARCHIVE VERIFICATION PENDING**

## Completed on the WP5 source work copy

| Surface | Result |
| --- | --- |
| Project Peer full Node suite | 134/134 PASS |
| Project Peer focused WP5 suite | 5/5 PASS |
| Project Peer syntax/check | 65 modules PASS |
| Server full Node suite | 72/72 PASS |
| Server syntax/check | 10 modules PASS |
| Launcher Core Release tests | 24/24 PASS |
| Launcher WPF Release build | PASS, 0 warnings, 0 errors |
| Unity 6000.3.21f1 EditMode | NOT RUN; licensing IPC timed out, no XML |
| Manual WP5 Windows field flow | NOT RUN |
| Formal two-PC WP4.1 closure | DEFERRED / FIELD BLOCKED |

The Unity log is retained under the source work copy only and is not packaged.
Domain reload without result XML is not a Unity test PASS.

## Staged candidate executable evidence

Candidate root: `Unity-TeamForge-0.5.1-WP5`. Commands were invoked from a
foreign working directory; all temporary logs/scratch stayed outside the staged
candidate.

| Gate | Result |
| --- | --- |
| Packaged Runtime manifest and execution | PASS; 93 files; Node 24.19.0 |
| Launcher manifest/integrity verifier | PASS; 495 files; all 9 checks |
| Launcher direct `--self-test-runtime` | PASS; `runtime_self_test_passed` |
| Corrupt Runtime isolated case | PASS; fail-closed exit 2 |
| Missing Runtime isolated case | PASS; fail-closed exit 2 |
| Hostile environment/fake Project Runtime | PASS; ignored and scrubbed |
| Staged repository validator | PASS; 940 files, 73 C# sources, Protocol v1 |
| Bundled Coordinator local listener | PASS; exact owned PID; 127.0.0.1:5080 only; health 0.5.1 / Protocol 1 / auth false |
| Bundled Coordinator LAN listener | PASS; exact owned PID; 0.0.0.0:5080; loopback and <private LAN address redacted> health; auth true |
| Listener/process cleanup | PASS; both exact owned processes stopped; no port 5080 listener remained |

The LAN credential existed only in the child-process environment and is not
included in this report or candidate. No unknown listener was stopped.

## Evidence boundary

Archive construction, SHA-256 sidecar, archive verifier/adversarial verifier,
and fresh Korean-and-space extraction run occur after this in-candidate report
is frozen. Their exact results belong in the adjacent final candidate
verification report. Unity EditMode and manual/two-PC field checks remain
**NOT RUN / DEFERRED** as stated above.
