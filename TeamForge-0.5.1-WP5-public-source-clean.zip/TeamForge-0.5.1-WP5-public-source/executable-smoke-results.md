# Executable and Script Smoke Results — TeamForge 0.5.1 WP4.1

Qualification status: **AUTOMATED SOURCE PASS / FIELD BLOCKED**

Audit date: 2026-08-15 (Asia/Seoul)

Temporary Node and .NET files were redirected to writable workspace-local
directories. The exact immutable ZIP is verified only after freeze; its digest
and clean-extraction evidence belong to the adjacent external final report.

## Product and regression gates

| Command / entrypoint | Exit | Actual result |
| --- | ---: | --- |
| `node --test test/guest-refresh.test.mjs` | 0 | 5/5 WP4.1 cases PASS |
| `npm.cmd test` in Project Peer | 0 | 129/129 PASS, including rev1 rejoin, rev2 refresh, UUID/Owner/tamper, Publisher trust, and failed rev2 |
| `npm.cmd run check` in Project Peer | 0 | 64 modules syntax checked |
| `npm.cmd test` in Server | 0 | 72/72 PASS |
| `npm.cmd run check` in Server | 0 | Ten modules syntax checked |
| `node scripts/validate-repository.mjs` | 0 | Product 0.5.1, Protocol v1, 71 C# sources; PASS |
| `node scripts/verify-runtime-bundle.mjs --source` | 0 | 93 manifest files; bundled runtime execution PASS |
| `node scripts/verify-runtime-bundle.mjs --packaged` | 0 | 93 manifest files; packaged execution PASS |
| `node scripts/verify-wp4-launcher.mjs --scratch-root <short-root>` | 0 | 495 Launcher files, 93 Runtime files; all nine checks PASS; corrupt/missing Runtime exit 2 |
| `dotnet run --project <Core.Tests.csproj> --configuration Release --no-restore` | 0 | Launcher Core 20/20 PASS on SDK 10.0.303 |
| `node --test launcher/test/runtime-loader.test.mjs` | 0 | 4/4 PASS |

The first full Project Peer invocation ran before Server `ws` was installed;
six Host/lifecycle cases became `needs_action` and two Server-import test files
failed with `ERR_MODULE_NOT_FOUND`. After the required locked Server install,
the unchanged full suite passed 129/129. This is a dependency-preparation
diagnostic, not a hidden product regression.

## Build and generated payload

| Command / entrypoint | Exit | Actual result |
| --- | ---: | --- |
| `node scripts/build-runtime-bundle.mjs --node-root <official-node-root> --node-archive <official-zip>` | 0 | 93 files; Node 24.19.0; Runtime manifest `adc1276b...63c5` |
| default `node scripts/build-wp4-launcher.mjs` | 1 | NuGet TLS/certificate retrieval failed as `NU1301`/`NU1900`; no product conclusion |
| explicit offline `dotnet restore ... --ignore-failed-sources -p:NuGetAudit=false` using the prior verified runtime-pack cache | 0 | Required .NET 10.0.11 packs restored locally; this is not a new audit |
| `node scripts/build-wp4-launcher.mjs --no-restore` | 0 | 495 generated files; Launcher manifest `07e61610...2b42b`; Runtime pin refreshed |

Default online restore remains the normal release behavior. `--no-restore` is
an explicit build-only escape hatch for a separately prepared, recorded local
asset graph; it does not disable the release contract's audit requirement.
No Launcher C# or NuGet dependency changed in WP4.1.

## Unity boundary

`powershell.exe -NoProfile -ExecutionPolicy Bypass -File
scripts/teamforge.ps1 unity-test` reached Unity 6000.3.21f1, compiled/loaded the
project, then remained in external Licensing Client IPC retries. After a
bounded wait, the wrapper was interrupted and only its owned Unity PID was
stopped. No result XML existed. Result: **NOT RUN**. Log SHA-256:
`70C8F99DA783A656232F822B6FB654ECD1779DC0F8FC7C0903F1928625773439`.

The prior candidate's byte-identical Unity C# sources have 130/130 PASS
evidence. That prior result is retained separately and is not counted as an
exact WP4.1 Unity execution.

## Post-freeze and manual boundary

Archive verification, adversarial duplicate-path rejection, exact Launcher
self-test, Korean/space extraction, wrapper smoke, and sidecar matching are
recorded after the immutable ZIP is created. The actual existing-Guest
two-PC refresh/rejoin checklist remains **NOT RUN / FIELD BLOCKED**.
