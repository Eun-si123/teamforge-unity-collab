# Unity TeamForge 0.5.1 WP5 Diagnostics & Recovery UX candidate

This Windows x64 release candidate adds beginner-facing diagnostics and safe,
state-driven recovery to the 0.5.1 WP4.1 existing-Guest refresh foundation.
The default Host/Guest UX stays simple; copyable redacted state and stable error
codes are under Advanced / Technical Details.

The candidate is **FIELD BLOCKED**, not WP5 or WP4.1 CLOSED. WP5 manual recovery
checks and the formal two-PC WP4.1 closure remain unrun/deferred against this
exact ZIP.

## Normal Windows use

Normal Host and Guest paths are self-contained. They do not require system
Node.js, npm, a repository checkout, `TEAMFORGE_WORKSPACE_ROOT`,
`TEAMFORGE_NODE_PATH`, a prepared PowerShell session, or a particular current
working directory.

1. Verify the ZIP with its adjacent `.sha256` sidecar.
2. Extract it to a reasonably short folder. Keep the candidate root name
   unchanged; a path such as `C:\TeamForge Test\팀포지\Unity-TeamForge-0.5.1-WP4`
   is suitable.
3. Host: install/use `unity-package/com.eunsung.teamforge` in Unity
   6000.3.x, open **Window > TeamForge**, choose **Host**, and complete
   **Publish & Start**.
4. For a second PC, choose a real LAN address to advertise. The Coordinator may
   listen on `0.0.0.0`, but an invite never advertises a wildcard, loopback,
   or unspecified endpoint.
5. Copy or save the **Collaboration Invite** produced by Host Ready. It is a
   `teamforge-bootstrap-invite-v1` envelope containing the independently
   validated signed Project Transfer invite and TF1 realtime session.
6. Guest: run
   `launcher/win-x64/TeamForge.Launcher.exe`, paste the Collaboration Invite
   and access code, review trust, receive the Project, and launch Unity.

For an existing Guest, keep the same managed root and paste the newly signed
Collaboration Invite. TeamForge accepts the refresh only when the Project UUID
and pinned Owner identity are unchanged. A changed Publisher still requires
the existing explicit fingerprint trust decision. A new verified Baseline is
staged and activated under a new immutable Active path before the current
pointer moves; transfer failure leaves the previous Active selected.

The TF1-only **Session Invite** is deliberately under Advanced. It is for an
already-provisioned matching Project and cannot bootstrap a fresh Guest.

When an operation fails, use only the actions shown for the inspected state.
**Open Existing Verified Project** opens an independently validated immutable
Active for offline work; it never joins the failed realtime session and never
bypasses Scene baseline validation. Copied diagnostics are current-run only,
bounded, and redact credentials and caller-supplied secrets.

## Security and compatibility boundaries

- Realtime Protocol v1, Project Transfer Protocol v1, and Manifest Schema v1
  are preserved.
- Realtime authority remains the configured TeamForge Server WebSocket.
- Project payloads remain direct HTTP between `project-peer` processes; the
  Coordinator does not relay payload bytes.
- LAN listen/bind and advertised Guest endpoints are separate. LAN exposure
  requires authentication; wildcard and loopback addresses are rejected as
  advertised two-PC endpoints.
- WebRTC, ICE, STUN, TURN, relay, NAT traversal, discovery, and automatic route
  fallback are outside this hotfix.
- Arbitrary Unity component/serialized-property synchronization remains the
  existing Known Limitation and is outside WP5.
- Persistent recovery, Host Migration, Protocol v2, and new authority semantics
  are outside WP5.
- The Windows Launcher is self-contained .NET 10 and embeds a manifest-pinned
  Node 24 Runtime. It is currently unsigned, so Publisher trust must be
  established by the distribution channel and the SHA-256 sidecar.

## Developer and release validation

System Node/npm are only for source development and release construction.
Supported developer lines and exact production pins are defined in
`release-contract.json`. Run commands from any directory by using an absolute
candidate path or the CWD-independent wrappers:

```powershell
& '<candidate>\scripts\teamforge.ps1' doctor
& '<candidate>\scripts\teamforge.ps1' verify
& '<candidate>\scripts\teamforge.ps1' unity-test
node '<candidate>\scripts\verify-runtime-bundle.mjs' --packaged
node '<candidate>\scripts\verify-wp4-launcher.mjs'
powershell -NoProfile -File '<candidate>\scripts\verify-wp4-archive.ps1' -ArchivePath '<candidate.zip>'
```

`Start-TeamForge-Local.cmd`, `Start-TeamForge-LAN.cmd`,
`Verify-TeamForge.cmd`, and `Run-Unity-Tests.cmd` are developer wrappers,
not the normal WP4 end-user launch path. The source scripts may install locked
development dependencies; the final Host/Guest Runtime never does.

## Evidence

- `Release-Integrity-Audit.md`
- `WP5-Diagnostics-Recovery-UX-Report.md`
- `changed-files-wp5.md`
- `Windows-Field-Test-Checklist-WP5.md`
- `executable-smoke-results-wp5.md`
- `dependency-runtime-version-audit.md`
- `supported-entrypoints-inventory.md`
- `executable-smoke-results.md`
- `WP4-Field-Hotfix-Report.md`
- `Windows-Field-Test-Checklist-WP4-Hotfix.md`

Historical Phase reports, rollback references, and old test evidence remain
under `docs/` and are listed in `historical-files-retained.txt`. They are
evidence, not current operational instructions.
## License

TeamForge-owned source in this tree is licensed under the **GNU Affero General Public License v3.0 only (AGPL-3.0-only)**. See `LICENSE`. Third-party components retain their own licenses and notices; for example, `ws` remains MIT-licensed and its notice is preserved.

