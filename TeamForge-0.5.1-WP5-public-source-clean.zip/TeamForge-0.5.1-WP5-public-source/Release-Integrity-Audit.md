# Release Integrity Audit — TeamForge 0.5.1 WP4.1

Status: **AUTOMATED SOURCE QUALIFICATION PASS / FIELD BLOCKED**

Audit date: 2026-08-15

## Immutable input

The previous TeamForge 0.5.1 WP4 candidate remains immutable:

- ZIP SHA-256:
  `27F2B5FCB68D66FCBCE932511992416D779CD67537B5FD2B467BF23A4865835D`
- release ID `0.5.1-wp4-field-hotfix`
- Protocol v1 and Windows x64

WP4.1 is generated as a separate artifact with release ID
`0.5.1-wp4.1-guest-refresh-hotfix`. Product compatibility version remains
0.5.1 because the protocol, package API, Launcher API, and serialized formats
are unchanged.

## Root cause and repair boundary

`ProjectPeerEngine.importInviteValue()` validated the new Owner signature but
then required exact JSON equality with the stored invite. Legitimate new
session IDs or endpoints therefore produced `invite_conflict`.

The repair revalidates the new invite and atomically refreshes only stored
session/endpoint invite metadata when Project UUID, Project ID, and Owner key
match. Project UUID drift, Owner drift, and tampering fail before replacement.
Publisher identity remains descriptor-scoped and uses the existing explicit
trust pin/challenge.

No Unity realtime Scene-baseline check was relaxed. No Active directory or
current pointer is changed during invite import. Managed activation still
requires staging, complete content/signature/Unity verification, Publisher
approval when needed, an immutable new Active path, and an atomic pointer
write.

## Automated qualification

| Gate | Result |
| --- | --- |
| Focused WP4.1 refresh/rejoin | PASS, 5/5 |
| Project Peer | PASS, 129/129; 64-module syntax check |
| Server | PASS, 72/72; 10-module syntax check |
| Repository invariant | PASS; product 0.5.1, Protocol v1, 71 C# sources |
| Runtime source and packaged verification | PASS; 93 files; bundled Node 24.19.0 executed |
| Runtime manifest | SHA-256 `adc1276b2db8d94b14b08bcea2fe7b86e2d1127024de164685a7aab7b24563c5` |
| Launcher | PASS; manifest/runtime pins regenerated; all nine hostile/corrupt/missing checks stable |
| Launcher manifest | SHA-256 `07e616106d7b17285ad9c086c579296766d3be85997d6dedbdb4131e31d3b42b` |
| Launcher Core | PASS, 20/20 |
| Runtime loader | PASS, 4/4 |
| Authenticode | `NotSigned` |

The default online .NET restore attempt was blocked by the current Windows
session's NuGet TLS/certificate failure (`NU1301`/`NU1900`). No C# or NuGet
dependency changed from the previously audited 0.5.1 source. The build reused
the previously verified local .NET 10.0.11 runtime-pack cache via an explicit
offline restore and `--no-restore` publish; this environment fallback is
recorded and is not represented as a new online vulnerability audit.

Unity 6000.3.21f1 was launched against the WP4.1 source, but its external
Licensing Client IPC timed out/refused and no result XML was produced. That
attempt is **NOT RUN**, not PASS or product FAIL. The Unity C# sources are
byte-identical to the prior candidate whose PowerShell 5.1 EditMode execution
passed 130/130; prior evidence is not relabeled as an exact WP4.1 run.

Exact ZIP/archive/adversarial verification and clean Korean/space extraction
are performed only after freeze and bound in the adjacent external final
verification report.

## Preserved invariants and exclusions

- Realtime, Project Transfer, and Manifest remain Protocol/Schema v1.
- Authority, signed Owner/Publisher identity, hashes, trust pins, direct HTTP,
  immutable Active revisions, and atomic current pointer remain intact.
- Existing verified Active content is never overwritten or deleted.
- WebRTC, ICE/STUN/TURN, relay, NAT traversal, discovery, and Scene-mismatch
  bypasses were not added.
- Arbitrary component/serialized-property synchronization remains the existing
  Known Limitation and is outside WP4.1.

## Residual status

The prior fresh-Guest field path is recorded as tester-reported PASS. The new
same-managed-root existing-Guest refresh/rejoin field checklist is **NOT RUN /
FIELD BLOCKED**. WP4.1 must not be called CLOSED until that exact candidate is
verified across the two Windows PCs.
