# Windows Field Test Checklist — WP5 Diagnostics & Recovery UX

Status at delivery: **NOT RUN manually**

Use the exact WP5 ZIP and verify its adjacent SHA-256 sidecar before testing.
Do not reuse a development tree as release evidence. Record both PCs, Windows
versions, Unity versions, network, timestamps, and the exact candidate hash.

## Default UX and secret safety

- [ ] Host and Guest default screens remain beginner-simple; technical fields
  appear only under Advanced / Technical Details.
- [ ] Copy Diagnostics works for Host and Guest and contains the expected stable
  code, operation, shortened Project identity, revision/Active, endpoint,
  ownership/health, transfer/staging/runtime stage, and current-run history.
- [ ] Paste known marker values as access code/token-like inputs; confirm none
  appears in the UI, clipboard diagnostic bundle, logs, or persisted settings.
- [ ] Repeated failures retain at most the bounded current-run history and a new
  application run does not restore the prior history.

## Deterministic recovery cases

- [ ] TeamForge version mismatch offers copy/upgrade guidance and does not mutate
  the managed root.
- [ ] Same Project/Owner new-session refresh uses the same managed root and
  rejoins without creating a new root.
- [ ] Newer approved Baseline creates a verified immutable Active and atomically
  moves current only after verification; Unity opens the new Active.
- [ ] Scene baseline mismatch remains rejected; no recovery button connects the
  stale Scene directly to realtime.
- [ ] Wrong access code offers Enter Access Code Again and never copies the code.
- [ ] Tampered Invite hard-fails and leaves binding/current/Active unchanged.
- [ ] Corrupt or incomplete bundled Runtime identifies the verification stage
  and does not fall back to system Node.
- [ ] Missing/wrong Unity executable offers Choose Unity Executable and does not
  launch an unverified project.
- [ ] Unsafe, reserved, UNC, reparse, or excessively long path fails before
  receive/open and offers a shorter managed-root choice where appropriate.
- [ ] Occupied port with unknown owner is not terminated; diagnostics show the
  unverified ownership state.
- [ ] Failed rev2 transfer leaves rev1 current and offers Retry plus Open Existing
  Verified Project only when that Active passes independent validation.
- [ ] Opening the previous verified Active does not create a realtime handoff or
  bypass Project/Scene baseline validation.

## Formal WP4.1 two-PC carry-forward

- [ ] rev1 Fresh Guest -> Host stop/restart -> same Baseline new session -> same
  Guest managed root -> new signed Invite -> successful rejoin.
- [ ] Host source change -> approved rev2 Publish -> same Guest managed root ->
  new signed Invite -> verified rev2 Active -> Unity open/rejoin.
- [ ] Changed Project UUID hard-fails.
- [ ] Changed Owner hard-fails.
- [ ] Changed Publisher invokes explicit trust and only proceeds after approval.
- [ ] Failed rev2 transfer preserves rev1 Active and current pointer.

Overall WP5 field gate: PASS / FAIL / **NOT RUN**

Formal WP4.1 two-PC closure: PASS / FAIL / **DEFERRED**
