# Dependency and Runtime Version Audit

Audit date: 2026-08-15 (Asia/Seoul)  
Release: Unity TeamForge 0.5.1 — WP4.1 Existing Guest Refresh / Rejoin Hotfix  
Release status: **FIELD BLOCKED** pending the manual two-PC existing-Guest refresh/rejoin checklist  
Compatibility boundary: Protocol v1 and the direct HTTP `project-peer` transfer design are unchanged.

## Decision summary

| Component | Hotfix selection | Upstream/support finding | Release decision |
| --- | --- | --- | --- |
| Bundled Node.js | 24.19.0, win-x64 | Current Node 24 Active LTS patch; scheduled EOL 2028-04-30 | Keep. It is the latest compatible security/patch release on the selected LTS line. |
| Supported source/developer fallback | Node 22.23.2 | Current Node 22 Maintenance LTS patch; scheduled EOL 2027-04-30 | Keep the 22 line supported at 22.23.2 or newer, below 23. Do not bundle it. |
| .NET Launcher runtime | .NET 10.0.11, self-contained win-x64 | Current .NET 10 security servicing release | Keep and regenerate the self-contained Launcher with this runtime. |
| .NET build SDK | 10.0.303 (`global.json`) | Supported SDK in the same .NET 10 servicing release; 10.0.400 is the newer feature band | Keep the validated 10.0.303 build pin for this hotfix. Validate 10.0.400 separately as follow-up. |
| `ws` | 8.21.3 | Current 8.x release; newer than the 8.21.0 security floor | Keep exact pin and exact SRI in every lockfile. |
| npm | 11.19.0, build/release tooling only | Current compatible npm 11 selection; npm 12 is a potentially breaking major | Pin npm 11.19.0 for reproducible release builds. Evaluate npm 12 separately; it is not an end-user runtime dependency. |
| Unity Editor/package line | Unity 6000.3.21f1 / package line 6000.3 | Unity 6000.3 is LTS; 6000.3.22f1 is the current upstream patch | Keep the installed and tested 6000.3.21f1 baseline for this hotfix. Test 6000.3.22f1 before moving the baseline. |
| TeamForge product components | 0.5.1 | Patch release for the WP4 Field hotfix | Server, Project Peer, Unity package, Launcher, Runtime manifest, Launcher manifest, generated pins, and release manifest must agree on 0.5.1. Dependency versions remain independent. |

## Node.js

The bundled runtime remains **Node.js 24.19.0 win-x64**. The official release index identifies 24.19.0 as the current Node 24 Active LTS patch. The official release schedule gives Node 24 an end-of-life date of 2028-04-30. Node 22 remains a supported source/developer line at **22.23.2** (Maintenance LTS, EOL 2027-04-30), but it is not the bundled executable.

The July 2026 Node security release establishes the accepted floors used by this release:

- `>=22.23.2 <23`
- `>=24.18.1 <25`

The bundled 24.19.0 executable is above that security floor. A move to a different major is not justified by this audit and is deliberately out of scope.

Supply-chain pins:

- Source archive: `node-v24.19.0-win-x64.zip`
- Official archive SHA-256: `57f71ab3652e797d84acddc79c81cc9ff1c6ddb2a1974cdb83f00fee9bff4c73`
- Extracted `node.exe` SHA-256: `3602f2bb1a10f2cbab4c36886218a33c1ab3db87290e73b033c46c77147d0237`
- The archive digest is checked against the official [Node 24.19.0 SHASUMS256](https://nodejs.org/download/release/v24.19.0/SHASUMS256.txt), then the generated Runtime manifest pins both the source archive and the shipped executable.

Primary sources: [Node release index](https://nodejs.org/dist/index.json), [Node release schedule](https://github.com/nodejs/release), and [July 2026 security releases](https://nodejs.org/en/blog/vulnerability/july-2026-security-releases).

## .NET Launcher

The Launcher remains a **self-contained `win-x64` .NET 10** application targeting `net10.0-windows`. The selected runtime is **10.0.11**, the current security servicing release on the audited date. The repository build SDK is fixed by `global.json` at **10.0.303** with `rollForward: latestPatch`; this SDK is supported in the same .NET 10 servicing release.

SDK **10.0.400** is a newer feature band, not a required runtime security uplift. It was not substituted into this hotfix because the current Launcher build/test baseline is 10.0.303 and a feature-band change needs its own reproducibility and regression evidence. Testing and adopting 10.0.400 is a follow-up, not a silent release change.

Primary sources: [.NET 10 release metadata](https://dotnetcli.blob.core.windows.net/dotnet/release-metadata/10.0/releases.json) and [.NET 10.0.11 release notes](https://github.com/dotnet/core/blob/main/release-notes/10.0/10.0.11/10.0.11.md).

The Windows Launcher binary is **NOT SIGNED**. Hash and manifest verification provide integrity evidence but do not replace Authenticode publisher identity. Code signing remains a release follow-up and is not reported as passed.

## `ws`, npm lockfiles, and registry evidence

Server and Project Peer keep the exact production dependency **`ws@8.21.3`**. The same exact version and integrity value are present in the root, Server, and Project Peer npm v3 lockfiles:

`sha512-201TZ/kPWxoPr/OKWjquZR1SWKXcvxdH+e1xrx89b3YbmzLMFCLfnaG1HFIgWzJOEWZ7MvpK++odZufgYR50Rw==`

`ws` 8.21.3 is the current 8.x release. Advisory [GHSA-96hv-2xvq-fx4p](https://github.com/advisories/GHSA-96hv-2xvq-fx4p) affects versions below 8.21.0, so the selected pin contains that fix. Release source: [`ws` 8.21.3](https://github.com/websockets/ws/releases/tag/8.21.3).

Registry checks against the selected lock graph produced:

- npm bulk-advisory response: `{}` (no advisory returned for the pinned production graph at audit time).
- npm ECDSA registry-signature verification: **PASS**.
- Pinned npm 11.19.0 `audit --omit=dev --audit-level=low`: Server exit 0,
  Project Peer exit 0, both `found 0 vulnerabilities`.
- Pinned npm 11.19.0 `audit signatures`: exit 0 in both workspaces; JSON
  reported `invalid: []` and `missing: []`.
- Registry signing key used by verification: `SHA256:DhQ8wR5APBvFHLF/+Tc+AYvPOdTpcIDqOhxsBHRwC7U`.
- Procedure source: [npm registry signatures](https://docs.npmjs.com/about-registry-signatures/).

These are dated, registry-backed checks, not a claim that future advisories cannot appear. Release policy continues to require both an npm vulnerability audit and registry-signature verification for each regenerated immutable candidate.

npm **11.19.0** is a build/release-tool pin only. The shipped Host/Guest runtime uses the bundled Node executable and vendored production dependency tree; normal users do not install or run npm. npm 12 is a major-version evaluation item and is not introduced in this compatibility hotfix.

`dotnet list package --vulnerable --include-transitive --no-restore` also
returned exit 0 with no vulnerable packages for Launcher Core, Launcher, and
Launcher Core.Tests under SDK 10.0.303.

## Unity

The package stays on the **Unity 6000.3** LTS line with **6000.3.21f1** as the candidate's installed/tested Editor baseline. Official upstream has since published **6000.3.22f1**. The newer patch was not installed or validated in this audit environment, so changing the declared test baseline to it would overstate evidence. Unity 6000.3.21f1 remains on the supported LTS line; 6000.3.22f1 should be installed and run through Unity EditMode plus the WP4 field workflow as a bounded follow-up.

Primary sources: [Unity 6000.3.22f1 release page](https://unity.com/releases/editor/whats-new/6000.3.22f1), [Unity 6 support and LTS policy](https://unity.com/releases/unity-6/support), and [Unity security advisory baseline](https://unity.com/security/sept-2025-01). The selected 6000.3.21f1 build postdates the cited security-remediation baseline; this does not substitute for monitoring later Unity advisories.

## Release consistency and residual status

`release-contract.json` is the authoritative current product/dependency relationship for this candidate. The release gate must reject drift in current operational metadata while allowing old version numbers inside explicitly classified historical evidence. In particular:

- TeamForge product version: `0.5.1` across current product components and generated manifests.
- Runtime/dependency selections: Node `24.19.0`, `ws` `8.21.3`, .NET runtime `10.0.11`, SDK `10.0.303`, Unity line `6000.3` / tested Editor `6000.3.21f1`.
- Protocols and manifest schemas: version 1; no WebRTC/ICE/STUN/TURN/Relay/NAT-traversal change.
- Launcher Authenticode: **NOT SIGNED**.
- Unity 6000.3.22f1 migration validation: **NOT RUN — FOLLOW-UP**.
- Prior Host → fresh Guest two-PC validation: **FIELD PASS reported by the tester**; not rerun in this dependency audit.
- WP4.1 existing Guest refresh/rejoin validation: **NOT RUN / FIELD BLOCKED**.

Accordingly, the dependency selections are suitable for candidate generation, but this audit does **not** declare WP4 closed.
