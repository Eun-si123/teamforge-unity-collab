# Changed Files — TeamForge 0.5.1 WP4.1 Guest Refresh / Rejoin Hotfix

Comparison base: immutable
`Unity-TeamForge-0.5.1-WP4-field-hotfix-win-x64.zip`, SHA-256
`27F2B5FCB68D66FCBCE932511992416D779CD67537B5FD2B467BF23A4865835D`.

## Canonical implementation and regression changes

- `project-peer/src/project-peer.mjs`
  - revalidates each new Invite;
  - rejects Project/Owner binding drift;
  - atomically refreshes signed session/endpoint metadata for the same binding.
- `project-peer/test/guest-refresh.test.mjs`
  - new five-case same-root refresh/rejoin regression suite.
- `scripts/validate-repository.mjs`
  - requires and statically guards the WP4.1 implementation/tests/status.

## Release construction and generated payload

- `scripts/build-wp4-launcher.mjs` adds an explicit `--no-restore` build-only
  mode; default restore/audit behavior remains unchanged.
- `scripts/verify-wp4-archive.ps1` and `release-contract.json` bind the WP4.1
  release ID/work package while keeping product version 0.5.1 and Protocol v1.
- Both nested `Runtime` payloads/manifests are regenerated from canonical
  Project Peer bytes and official Node 24.19.0.
- Launcher Runtime pins, self-contained binaries, and Launcher manifest are
  regenerated for the new Runtime manifest.
- The final `release-manifest.json` is generated only from the staged payload.

## Current documentation/evidence

- `README.md`
- `docs/project-state.md`
- `docs/roadmap.md`
- `docs/known-issues.md`
- `WP4-Field-Hotfix-Report.md`
- `Release-Integrity-Audit.md`
- `Windows-Field-Test-Checklist-WP4-Hotfix.md`
- `executable-smoke-results.md`
- `supported-entrypoints-inventory.md`
- `dependency-runtime-version-audit.md`
- `removed-deprecated-obsolete-files.md`
- this changed-files report

## Exact staged delta

The pre-freeze staged payload contains 1,007 manifest rows versus 1,006 in the
comparison candidate:

- added: **1**
- modified: **26**
- removed: **0**
- unchanged: **980**

Added:

- `project-peer/test/guest-refresh.test.mjs`

Modified:

- `README.md`
- `Release-Integrity-Audit.md`
- `WP4-Field-Hotfix-Report.md`
- `Windows-Field-Test-Checklist-WP4-Hotfix.md`
- `changed-files-wp4-release-integrity-hotfix.md`
- `dependency-runtime-version-audit.md`
- `docs/known-issues.md`
- `docs/project-state.md`
- `docs/roadmap.md`
- `executable-smoke-results.md`
- `launcher/src/TeamForge.Launcher/RuntimePins.g.cs`
- `launcher/win-x64/TeamForge.Launcher.Core.dll`
- `launcher/win-x64/TeamForge.Launcher.dll`
- `launcher/win-x64/launcher-manifest.json`
- `launcher/win-x64/Runtime/backend/project-peer/src/project-peer.mjs`
- `launcher/win-x64/Runtime/runtime-manifest.json`
- `project-peer/src/project-peer.mjs`
- `release-contract.json`
- `removed-deprecated-obsolete-files.md`
- `scripts/build-wp4-launcher.mjs`
- `scripts/validate-repository.mjs`
- `scripts/verify-wp4-archive.ps1`
- `supported-entrypoints-inventory.md`
- `unity-package/com.eunsung.teamforge/Editor/UX/TeamForgeRuntimeManifest.g.cs`
- `unity-package/com.eunsung.teamforge/Runtime~/backend/project-peer/src/project-peer.mjs`
- `unity-package/com.eunsung.teamforge/Runtime~/runtime-manifest.json`

Removed: none.

## Explicit non-changes

- Protocol v1, Authority, trust tuple, direct HTTP transfer, hashing,
  signatures, immutable Active, and atomic current-pointer semantics.
- Unity C# product/runtime sources and serialized formats.
- Server product/runtime sources.
- Arbitrary component/serialized-property synchronization (Known Limitation).
- WebRTC, ICE/STUN/TURN, relay, discovery, and NAT traversal.
