# Supported Entrypoints Inventory

Release contract: Unity TeamForge 0.5.1, `0.5.1-wp4.1-guest-refresh-hotfix`, `win-x64`  
Inventory date: 2026-08-15 (Asia/Seoul)  
Release state: **FIELD BLOCKED** until the manual existing-Guest refresh/rejoin checklist is completed.

This is the authoritative inventory of things that may be executed from the 0.5.1 candidate. “Supported” identifies an intended surface; it is not an execution claim. The exact fresh-candidate results belong in `executable-smoke-results.md`.

## Evidence boundary

| Evidence set | Result | What it proves |
| --- | --- | --- |
| Supplied 0.5.0 candidate, SHA-256 `BE670483F6348C8F6197DD09F5E516E3913140E8C0A140D778884808D215A310` | Archive verifier and adversarial-verifier PASS; Server 72/72; Project Peer 122/122; 184 repository-owned `.mjs` syntax checks; Launcher loader 3/3; Launcher core 20/20 using a shorter DLL path; Launcher runtime self-test PASS; foreign-CWD Server health and the Server/Peer smoke and check surfaces PASS | Prior-candidate characterization only. It does **not** validate changed 0.5.1 files or the rebuilt artifacts. |
| Supplied 0.5.0 defects | `scripts/teamforge.ps1 smoke` exited 1 because `smoke` was treated as an unknown npm command; obsolete `scripts/validate-hotfix-windows.ps1` exited 1; default Runtime verification selected the wrong mode; the Launcher verifier’s canonical self-test passed but its overall run exited 1 after a long-scratch-path CLR failure; the Unity Runtime `node.exe` failed to start at a 262-character path; the .NET test executable failed at a 278-character path | These failures motivated the repaired entrypoint and short-root contracts. They are not carried forward as passes. |
| Supplied 0.5.0 checks not performed | Unity EditMode, Docker, Bash execution, LAN/two-PC field flow: **NOT RUN** | No inference is permitted from static inspection or another platform. |
| Repaired 0.5.1 WP4.1 source | Automated source qualification PASS | Server 72/72; Project Peer 129/129 including five refresh/rejoin regressions; Launcher Core 20/20; loader 4/4; Runtime and Launcher gates PASS. Unity exact repeat is licensing-blocked and recorded as NOT RUN. Exact archive evidence is bound after freeze. |

## Classification

- **User**: intended normal Host/Guest product path.
- **Developer**: supported source-tree operation; may require installed Node/npm, .NET SDK or Unity Editor.
- **Build/release**: release engineering only; not a participant workflow.
- **Internal**: launched by another TeamForge component; direct invocation is unsupported.
- **Test/support**: a deterministic check or fixture, not a product command.
- **Generated payload**: shipped executable content whose source of truth is the canonical source plus build scripts.

## Normal product entrypoints

| Path or UI surface | Class | Supported invocation and ownership | 0.5.1 evidence |
| --- | --- | --- | --- |
| `launcher/win-x64/TeamForge.Launcher.exe` | User, Guest | Double-click the self-contained Windows Launcher. It verifies its adjacent manifest-pinned Runtime, accepts a newly signed same-Project/Owner Collaboration Invite in the existing managed root, retains explicit Publisher trust, downloads the project and launches Unity. `--self-test-runtime` is diagnostic. | Runtime self-test and hostile/corrupt/missing Runtime gates **PASS**; prior fresh bootstrap field PASS was reported by the tester; WP4.1 two-PC refresh/rejoin is **NOT RUN**. |
| `Window > TeamForge > Collaboration` (`TeamForgeHomeWindow`) | User, Host/installed Guest | Primary Unity UI. Host performs preflight, explicit Publish, protected Coordinator/Seed startup, and copies or saves one signed `teamforge-bootstrap-invite-v1` Collaboration Invite. The advanced TF1 code is session-only and is not a Launcher invite. | Unity compile/EditMode **130/130 PASS**; interactive/two-PC flow **NOT RUN**. |
| `Window > TeamForge > Advanced` (`TeamForgeWindow`) | Advanced developer/user | Detailed realtime/project controls and diagnostics. It is supported for diagnosis and existing-project session work, but it is not the standalone Guest bootstrap path. | Unity compile/EditMode **130/130 PASS**; interactive click-through **NOT RUN**. |
| `Window > TeamForge > Test Lab` (`TeamForgeTestLabWindow`) | Developer/test | Controlled clone/test utilities inside Unity. It is not a field-participant entrypoint. | Unity compile/EditMode **130/130 PASS**; interactive multi-Editor lab **NOT RUN**. |

Unity `[InitializeOnLoad]` services under `Editor/` are lifecycle components loaded by Unity, not separate user commands. They must not be invoked as standalone executables.

## Windows, PowerShell and shell entrypoints

There are no repository-owned `.bat` files.

| Path | Class | Supported behavior | 0.5.1 evidence |
| --- | --- | --- | --- |
| `Start-TeamForge-Local.cmd` | Developer | CWD-independent wrapper for `scripts/teamforge.ps1 server`; binds the source Coordinator to loopback. | Foreign-CWD start and `/health` **PASS**; owned process tree stopped. |
| `Start-TeamForge-LAN.cmd` | Developer | CWD-independent wrapper for `scripts/teamforge.ps1 server -Lan -GenerateToken`; starts an authenticated source Coordinator listener for controlled LAN development. It is not the Unity Host orchestration flow. | Foreign-CWD authenticated start and `/health` **PASS** with inherited ephemeral token; owned tree stopped. |
| `Verify-TeamForge.cmd` | Developer/test | CWD-independent wrapper for `scripts/teamforge.ps1 verify`. | Validator, Server 72/72 and Project Peer 129/129 are the current expected gate. |
| `Run-Unity-Tests.cmd` | Developer/test | CWD-independent wrapper for `scripts/teamforge.ps1 unity-test`. | Dispatch verified; repeat was Unity-license-blocked with no XML and is **NOT RUN**. The underlying official PowerShell 5.1 entrypoint separately returned 130/130 PASS. |
| `scripts/teamforge.ps1` | Developer | Dispatcher commands: `doctor`, `install`, `server`, `dev`, `test`, `smoke`, `verify`, `unity-test`; optional switches: `-Lan`, `-GenerateToken`, `-UnityProject`, `-UnityEditorPath`. The repaired `smoke` branch invokes `npm run smoke`. | doctor/smoke/verify/server/LAN/unity-test exercised; all bounded product invocations **PASS**. `install` is covered by isolated fresh `ci`; `dev` delegates doctor+server. |
| `scripts/run-unity-tests.sh` | Developer/test | Bash helper requiring absolute `UNITY_EDITOR`; runs Unity EditMode tests into `artifacts/unity-tests`. Retained for source portability, but Bash execution is outside the win-x64 product path. | **NOT RUN**; Bash/macOS/Linux execution is outside this Windows x64 candidate. |
| `scripts/verify-wp4-archive.ps1` | Build/release | Validates a supplied `-ArchivePath`: canonical one-root ZIP layout, Windows-safe paths, limits, required files and pinned manifests. | Pre-freeze archive exit 0; **PASS**. |
| `scripts/test-wp4-archive-verifier.ps1` | Test/support | Requires `-ArchivePath`; creates a disposable adversarial ZIP and proves the archive verifier rejects a noncanonical duplicate path. | Exit 0; `noncanonical_duplicate_zip_path_rejected`; **PASS**. |

## npm-declared entrypoints

These are source/developer scripts. Generated Runtime package manifests deliberately contain **no `scripts` field** and are not npm-operated applications.

| Package | Declared script or bin | Target / purpose | Class |
| --- | --- | --- | --- |
| root `package.json` | `install:server` | `npm --prefix server ci` | Developer |
| root `package.json` | `install:peer` | `npm --prefix project-peer ci` | Developer |
| root `package.json` | `install:all` | Runs both isolated installs | Developer |
| root `package.json` | `preflight` | `project-peer/src/preflight-cli.mjs inspect` | Developer |
| root `package.json` | `repair:dependencies` | Explicitly confirmed preflight dependency repair | Developer, mutating |
| root `package.json` | `start` | Delegates to the Server `start` script | Developer |
| root `package.json` | `test` | Server tests, Project Peer tests, repository validator | Developer/test |
| root `package.json` | `smoke` | Server smoke then Project Peer smoke | Developer/test |
| root `package.json` | `validate` | Repository static/integrity validator | Developer/test |
| `server/package.json` | `start` | `node src/index.mjs` | Developer/deployment |
| `server/package.json` | `test` | Node test runner over Server tests | Test |
| `server/package.json` | `smoke` | `server/scripts/smoke.mjs` | Test |
| `server/package.json` | `check` | Syntax-checks all ten Server source modules | Test |
| `project-peer/package.json` | `check` | `project-peer/scripts/check.mjs`; syntax-checks Project Peer source, scripts and tests | Test |
| `project-peer/package.json` | `preflight` | `project-peer/src/preflight-cli.mjs inspect` | Developer |
| `project-peer/package.json` | `smoke` | `project-peer/scripts/smoke.mjs` | Test |
| `project-peer/package.json` | `test` | Node test runner over Project Peer tests | Test |
| `project-peer/package.json` | bin `teamforge-project-peer` | `project-peer/src/cli.mjs` | Developer/advanced |
| `project-peer/package.json` | bin `teamforge-preflight` | `project-peer/src/preflight-cli.mjs` | Developer |

## Server, Project Peer and bridge executables

| Path | Commands or protocol | Class |
| --- | --- | --- |
| `server/src/index.mjs` | Starts the HTTP health endpoint and Protocol v1 WebSocket/Project Coordinator Server from validated `TEAMFORGE_*` environment settings. | Developer/deployment |
| `server/src/lifecycle-child.mjs` | Authenticated IPC child used by Host orchestration; refuses execution without the expected parent IPC, instance ID and token. | Internal |
| `server/scripts/smoke.mjs` | Loopback HTTP/WebSocket smoke with ephemeral process state. | Test |
| `project-peer/src/cli.mjs` | `help`; `init-owner`; `owner-key backup`; `invite create`; `invite import`; `status`; `repair-source-descriptor`; `publish`; `seed`; `sync`. | Developer/advanced |
| `project-peer/src/preflight-cli.mjs` | `inspect`; `repair-dependencies --confirm-repair`; supports workspace, launch-settings, project/managed roots, Server/Seed host/port and timeout options. | Developer |
| `project-peer/src/host-orchestrator-cli.mjs` | Newline-delimited JSON IPC operations `inspect`, `repairDependencies`, `planHost`, `commitHost`, `stop`; used by Unity. | Internal |
| `project-peer/src/guest-orchestrator-cli.mjs` | Newline-delimited `teamforge-guest-bridge-v1` operations `health`, `inspect`, `start`, `trust`, `pause`, `resume`, `cancel`, `shutdown`; used by the Launcher through the verified loader. | Internal |
| `project-peer/scripts/smoke.mjs` | Direct-transfer manifest/chunk smoke in a disposable tree. | Test |
| `project-peer/scripts/check.mjs` | Project Peer syntax-check driver. | Test |
| `project-peer/support/download-child.mjs` | IPC child fixture for partial/resumed download tests. | Test/support |

All other `server/src/*.mjs` and `project-peer/src/*.mjs` files are importable implementation modules, not standalone command-line contracts.

## Test groups

Server test discovery is the six files below:

- authority and realtime: `server/test/session-authority.test.mjs`, `server/test/server.test.mjs`
- project coordination: `server/test/project-coordinator.test.mjs`, `server/test/project-coordinator-core.test.mjs`
- model/policy: `server/test/hierarchy-model.test.mjs`, `server/test/policy-profile.test.mjs`

Project Peer test discovery is the following 23 test files; `project-peer/test/helpers.mjs` is shared test support rather than a standalone product entrypoint:

- invitation, identity and Guest safety: `bootstrap-invite.test.mjs`, `guest-active-validation.test.mjs`, `guest-bridge.test.mjs`, `guest-orchestrator.test.mjs`, `guest-safety.test.mjs`, `identity-descriptor.test.mjs`
- CLI, policy, preflight and lifecycle: `cli-policy.test.mjs`, `host-orchestrator.test.mjs`, `orchestrator-contract.test.mjs`, `policy-profile.test.mjs`, `process-lifecycle.test.mjs`, `unified-preflight.test.mjs`, `wp4-unity-host-handoff-static.test.mjs`
- project state and compatibility: `managed-project.test.mjs`, `manifest-path.test.mjs`, `project-engine.test.mjs`, `server-engine-e2e.test.mjs`
- direct transfer and coordinator integration: `coordinator-client.test.mjs`, `direct-transfer.test.mjs`, `project-transfer-integration.test.mjs`, `swarm-downloader.test.mjs`, `transfer-source-contract.test.mjs`, `transport-e2e.test.mjs`

## Build and release modules

| Path | Contract | Class |
| --- | --- | --- |
| `scripts/validate-repository.mjs` | Validates cross-component versions, Protocol v1 invariants, docs, generated/runtime shape and repository safety. | Build/release |
| `scripts/build-runtime-bundle.mjs` | Requires verified `--node-root` and `--node-archive`; regenerates Unity `Runtime~`, production dependencies and file manifest. | Build/release, mutating |
| `scripts/verify-runtime-bundle.mjs` | Verifies generated Runtime hashes/canonical parity and bundled execution. `--source` and `--packaged` are explicit overrides; with neither, it uses source mode only when both canonical `ws` installs exist, otherwise packaged mode. | Build/release |
| `scripts/build-wp4-launcher.mjs` | Generates Runtime pins, publishes self-contained `win-x64`, copies the verified Runtime/loader, and writes the Launcher manifest. | Build/release, mutating |
| `scripts/verify-wp4-launcher.mjs` | Verifies Launcher/Runtime exact manifests, core tests, self-test and adversarial cases. `--scratch-root` provides a caller-controlled short writable test root. | Build/release |
| `scripts/stage-wp4-release.mjs` | Requires dedicated absolute `--staging`; copies only allowlisted source/generated deliverables and writes the release manifest. | Build/release, mutating |
| `launcher/runtime-loader.mjs` | Adjacent Launcher-owned loader. It accepts only internal `--runtime-root` and `--manifest-sha256`, scrubs environment injection, verifies every Runtime file and loads the Guest bridge. | Internal/generated payload |
| `launcher/test/runtime-loader.test.mjs` | Loader unit/adversarial test group. | Test |

## Generated Runtime package declarations

`scripts/build-runtime-bundle.mjs` regenerates all three Runtime package manifests from canonical 0.5.1 manifests, removes `scripts` and `packageManager`, and adds `teamforgeRuntimeOnly: true`.

- `Runtime~/backend/package.json`: workspace metadata only; no scripts and no bins.
- `Runtime~/backend/server/package.json`: runtime dependency/engine metadata only; no scripts and no bins. The Host uses explicit trusted module paths.
- `Runtime~/backend/project-peer/package.json`: no scripts; the only retained bins are `teamforge-project-peer -> src/cli.mjs` and `teamforge-preflight -> src/preflight-cli.mjs`, and both target files exist in the generated Runtime.
- `Runtime~/platforms/win-x64/node.exe`: internal pinned Node 24.19.0 executable. It is launched by trusted Runtime/Launcher code, not offered as a general Node installation.

The identical Runtime copied under `launcher/win-x64/Runtime` is generated payload, not a second source tree.

## .NET projects and executables

| Path | Output | Class |
| --- | --- | --- |
| `launcher/src/TeamForge.Launcher/TeamForge.Launcher.csproj` | WPF `WinExe`, `net10.0-windows`, self-contained `win-x64`; publishes `launcher/win-x64/TeamForge.Launcher.exe`. | User/build |
| `launcher/src/TeamForge.Launcher.Core/TeamForge.Launcher.Core.csproj` | `net10.0` class library consumed by Launcher and tests; no direct executable. | Internal |
| `launcher/tests/TeamForge.Launcher.Core.Tests/TeamForge.Launcher.Core.Tests.csproj` | `net10.0` console test harness. | Test |
| `launcher/win-x64/createdump.exe` | Microsoft .NET runtime diagnostic payload; not a TeamForge user command. | Generated/internal |

## Container surface

`server/Dockerfile` and `server/compose.yaml` form a source/deployment alternative for the Coordinator (`node src/index.mjs`). They are not used by the standalone Windows Launcher and have **NOT RUN** status for this release unless `executable-smoke-results.md` explicitly records otherwise.

## Exclusions

- No WebRTC, relay, NAT traversal or cloud signaling entrypoint exists.
- Protocol v1 realtime and direct HTTP `project-peer` transfer remain the compatibility boundary.
- Files below `node_modules`, Unity `Library`/`Temp`/`Logs`, `.NET` `bin`/`obj`, build scratch trees and historical Markdown are not supported executable surfaces.
- Removed and superseded surfaces are recorded in `removed-deprecated-obsolete-files.md`.
