# TeamForge Public Source Cleanup Report

Prepared from `Unity-TeamForge-0.5.1-WP5-diagnostics-recovery-ux-win-x64.zip`. The original archive was not modified.

## Changes made

- TeamForge-owned license files changed from MIT to GNU AGPL v3.0 only.
- `package.json` / workspace lockfile metadata for TeamForge-owned packages changed to `AGPL-3.0-only`.
- Third-party `ws` MIT license metadata and `server/THIRD_PARTY_NOTICES.md` were intentionally preserved.
- Added `project-peer/LICENSE`.
- Replaced machine-local Windows username paths in the path-length regression test with an equal-length generic placeholder so the test keeps the same semantics.
- Redacted the one machine-local LAN address recorded in `executable-smoke-results-wp5.md`; documentation/test example addresses remain unchanged.
- Redacted internal container working paths from historical work-state notes while retaining their meaning.
- Strengthened `.gitignore` for local owner/publisher keys, invite files, tokens, and private-key containers.
- Removed generated release payloads from this public-source snapshot: `launcher/win-x64/`, `unity-package/com.eunsung.teamforge/Runtime~/`, and `release-manifest.json`. These are build/release outputs, not canonical source.

## Important boundary

This is a **source snapshot for review/publication**, not a byte-identical replacement for the previously tested WP5 release ZIP. Removing generated payloads and changing licensing metadata intentionally invalidates the old release manifest/hash evidence. Build a fresh release candidate and regenerate manifests/hashes before calling a binary release verified.

The existing polished public GitHub README may be preferable to this internal WP5 candidate README; merge source directories carefully rather than blindly replacing public-facing documentation.

## Validation performed

- `project-peer/test/cli-policy.test.mjs`: **3/3 PASS** after the equal-length path redaction.
- Server Node suite: **72/72 PASS** using the exact bundled `ws@8.21.3` dependency copied temporarily for testing; temporary `node_modules` were removed afterward.
- Project Peer suite in this Linux container: **121/134 PASS, 12 environment-blocked failures**. Every failure routes through TeamForge's Node security-floor check because this container has Node `22.16.0`, below TeamForge's required `>=22.23.2 <23 || >=24.18.1 <25`. The failures are therefore not claimed as product failures or passes.
- Secret-pattern scan found no GitHub/OpenAI/AWS keys, PEM private keys, or secret-like files. Remaining suspicious literals are explicit test/smoke fixtures intended to verify redaction/rejection behavior.
- JSON license metadata was parsed and checked: TeamForge-owned package records are `AGPL-3.0-only`; `ws` remains `MIT`.

A fresh binary/release build should still be generated and validated on the supported Node/Unity/Windows toolchain before release.
