# Removed, Deprecated and Superseded Surfaces

Release: Unity TeamForge 0.5.1 — WP4.1 Existing Guest Refresh / Rejoin Hotfix  
Inventory date: 2026-08-15 (Asia/Seoul)  
Release state: **FIELD BLOCKED** pending manual existing-Guest refresh/rejoin validation.

This report distinguishes removal from preservation. “Removed” means absent from the staged 0.5.1 candidate. “Superseded” means retained only as historical input or replaced as current authority; it must not be used as 0.5.1 operational guidance or execution evidence.

## Removed executable file

| Exact path | Disposition | Reason |
| --- | --- | --- |
| `scripts/validate-hotfix-windows.ps1` | **REMOVED** from source and staging | It was an obsolete Phase 3/v0.4.1 validator, required the wrong Node 20-era workflow, exercised incompatible root workspace installation behavior and could print a stale phase PASS. Its supplied-candidate execution exited 1. The supported replacement is `scripts/teamforge.ps1 verify` plus the explicit build/release gates listed in `supported-entrypoints-inventory.md`. |

No replacement shim is provided: retaining the filename could let old automation mistake a historical partial gate for 0.5.1 release approval.

## Superseded root release evidence

The following 0.5.0 WP4 files remain available in the preserved supplied archive and audit working copy, but are intentionally omitted by the 0.5.1 staging allowlist:

| Prior path | Current replacement | Disposition |
| --- | --- | --- |
| `ux-bootstrap-wp4-guest-bootstrap-report.md` | `WP4-Field-Hotfix-Report.md` and `Release-Integrity-Audit.md` | Supplied-candidate report; not 0.5.1 evidence |
| `changed-files-ux-bootstrap-wp4.md` | `changed-files-wp4-release-integrity-hotfix.md` | Supplied-candidate change inventory; not the hotfix delta |
| `Windows-Field-Test-Checklist-WP4.md` | `Windows-Field-Test-Checklist-WP4-Hotfix.md` | Supplied-candidate checklist; unchecked items do not transfer and prior wording does not close the hotfix |
| supplied `release-manifest.json` | freshly generated staged `release-manifest.json` | Generated evidence must describe the exact staged 0.5.1 bytes; the 0.5.0 manifest is not copied forward |

The original ZIP and its `.sha256` sidecar are preserved outside this working candidate. Nothing in this report authorizes their deletion.

## Superseded operational fields and behaviors

| Prior surface | 0.5.1 disposition |
| --- | --- |
| Product version `0.5.0` used independently across component metadata | Superseded by `release-contract.json` product version `0.5.1`; Server, Project Peer, Unity package, Launcher, Runtime, generated pins and staged release manifest must agree. Dependency versions remain independent. |
| Broad Node engines `^22.0.0 || ^24.0.0` | Superseded by security-patched floors `>=22.23.2 <23 || >=24.18.1 <25`; generated Runtime declarations inherit the same contract. |
| Runtime package `scripts` and root `packageManager` declarations copied from the source workspace | **REMOVED from generated Runtime manifests**. Runtime packages are marked `teamforgeRuntimeOnly`, are not npm-operated applications and retain only bins whose target files are actually present. |
| `scripts/verify-runtime-bundle.mjs` assuming source mode by default | Superseded by deterministic auto-detection: source mode only when both canonical `ws` installations exist; otherwise packaged mode. `--source` and `--packaged` remain explicit overrides and are mutually exclusive. |
| Launcher verifier using only its repository-relative default scratch path | Superseded by `--scratch-root`, allowing the release gate to select a short writable Korean/space-path test root and avoid false CLR failures from Windows path length. |
| Supplied archive’s long internal candidate-root name | **REMOVED from the packaging layout**. The 0.5.1 ZIP uses a short internal root governed by the archive verifier’s 48-character root-name limit, preserving headroom for Unity Package Cache and nested Runtime executables. |
| `scripts/teamforge.ps1 smoke` dispatching `npm ... smoke` | Superseded by `npm ... run smoke`; source and pre-freeze foreign-CWD executions pass. Exact immutable-candidate evidence is carried by the adjacent final verification report. |
| Isolated `npm --prefix <workspace> ci` without workspace suppression | Superseded by `--ignore-scripts --workspaces=false` in the root install scripts and all four PowerShell repair/install calls. This prevents npm 11 from hoisting `ws` into the workspace root while readiness checks require the two isolated dependency trees. |
| Unity test wrapper using `Start-Process -Wait` | Superseded by an exact Unity process handle plus `WaitForExit()`. The old form could retain the wrapper after Unity exited because a Unity-spawned `dotnet.exe` remained alive. The current PowerShell 5.1 wrapper returns, validates fresh XML/counts, and reports 130/130. |
| Normal Collaboration window’s ambiguous `Copy Invite`/project-invite wording when only a TF1 session code was available | **REMOVED from the normal Host-ready path**. The normal action copies/saves only the signed Collaboration Invite. The TF1-only action remains explicitly labeled `Copy session-only TF1 code` inside Advanced for collaborators who already have the exact project. |
| Host Ready succeeding without fresh realtime session data | **REMOVED**. Host orchestration fails closed with `realtime_session_missing` before Coordinator or Seed startup when the signed Collaboration Invite cannot include the realtime session. |
| One address being treated simultaneously as Coordinator bind address and Guest-advertised address | Superseded by separate `coordinatorListenHost` and advertised `serverAddress` semantics. Wildcard addresses may bind but cannot be advertised; inconsistent loopback/LAN combinations fail closed. |
| Non-loopback Coordinator startup without a separate access code | **REMOVED**. An exposed listener requires separately shared authentication before startup; credentials remain excluded from the signed invitation. |
| Direct Seed invitation constructed from a loopback or wildcard host, or from a requested rather than actual dynamic port | **REMOVED**. The Host path advertises a validated LAN-reachable host with the actual bound Seed port. |
| Current documentation presenting Node/npm source setup as a normal standalone Guest requirement | Superseded. Node/npm are developer/build prerequisites only; the Windows Guest Launcher uses its verified bundled Runtime. |
| Unqualified historical `PASS`, `CLOSED`, Phase 3, Phase 4 or 0.5.0 statements as current release state | Superseded by the 0.5.1 WP4.1 `FIELD_BLOCKED` contract and exact current evidence. The prior fresh bootstrap field PASS does not close the new rejoin checklist. |

## Historical evidence preserved in the staged candidate

`historical-files-retained.txt` names 112 retained artifacts: 111 reports,
checklists, rollback references, decisions, plans, session/test records and the
frozen 0.5.0 compatibility fixture under `docs/`, plus the append-only Unity
package changelog. They are intentionally retained for traceability and are
classified as **HISTORICAL EVIDENCE**. Their older versions, commands, counts
and PASS/CLOSED statements are not current instructions and do not validate
0.5.1.

Current authority is limited to:

- `release-contract.json`
- the current unversioned operational documentation and component READMEs
- `WP4-Field-Hotfix-Report.md`
- `Release-Integrity-Audit.md`
- `dependency-runtime-version-audit.md`
- `supported-entrypoints-inventory.md`
- `executable-smoke-results.md`
- `Windows-Field-Test-Checklist-WP4-Hotfix.md`
- the freshly generated `release-manifest.json` and ZIP `.sha256`

## Compatibility surfaces explicitly retained

The cleanup does **not** remove or replace these boundaries:

- realtime Protocol v1
- Project Transfer/manifest Protocol v1
- authoritative Server/WebSocket and Project Coordinator adapters
- direct HTTP `project-peer` transfer
- signed `teamforge-bootstrap-invite-v1` trust/bootstrap envelope
- supported advanced TF1 session-only join for collaborators who already possess the exact project

No WebRTC, relay, NAT traversal or unrelated transport migration was introduced.

## Evidence rule

Removal/supersession is established by source and staging inspection. Replacement
source/pre-freeze execution is recorded in `executable-smoke-results.md`, and
post-freeze execution is SHA-256-bound by the adjacent external final-candidate
report. Unity EditMode is 130/130 PASS. The actual two-PC Host → Launcher →
Unity path remains `NOT RUN / BLOCKED`; automated results do not replace it.
