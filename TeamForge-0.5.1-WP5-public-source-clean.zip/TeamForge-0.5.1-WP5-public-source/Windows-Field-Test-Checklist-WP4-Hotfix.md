# Windows Field Test Checklist — WP4.1 Existing Guest Refresh / Rejoin

Status at delivery: **NOT RUN manually**

Candidate ZIP: ________________________________________________

SHA-256: ______________________________________________________

Host PC / Windows / Unity: ____________________________________

Guest PC / Windows / Unity: ___________________________________

Tester and date: ______________________________________________

The prior WP4 fresh-Guest path was reported successful by the field tester.
Do not reuse that statement as proof of the new WP4.1 refresh/rejoin cases.
All items below must be performed against the exact new immutable ZIP.

## A. Artifact and prerequisite

- [ ] ZIP SHA-256 matches the adjacent sidecar on both PCs.
- [ ] Both PCs use files extracted only from this ZIP, with no source-tree or
      system-Node fallback.
- [ ] Guest managed root contains the previously verified rev1 immutable Active
      and a valid `current.json` selecting rev1.
- [ ] Record rev1 Active path and current-pointer SHA-256 before refresh.
- [ ] Directly connecting the stale rev1 Scene to an incompatible new realtime
      Scene baseline is still rejected; no bypass is offered.

## B. Same Baseline, new Host session

- [ ] Host closes the prior collaboration and starts a new collaboration using
      the same Project UUID, Owner, approved Baseline revision, and Publisher.
- [ ] Host produces a newly signed `teamforge-bootstrap-invite-v1` and, when
      LAN auth is enabled, a separately communicated access code.
- [ ] Guest pastes the new Invite into the Standalone Launcher and selects the
      same existing TeamForge managed root.
- [ ] Launcher does not report `invite_conflict` for the same Project/Owner.
- [ ] No new Publisher approval is requested when the Publisher pin matches.
- [ ] Receive completes without creating a second rev1 Active directory.
- [ ] `current.json` and the rev1 Active bytes remain unchanged.
- [ ] Unity opens the existing verified rev1 Active and applies the new one-shot
      realtime handoff/session.
- [ ] Host and Guest can rejoin, collaborate, save, and close normally.

## C. New approved Baseline revision

- [ ] Host changes source, explicitly publishes approved rev2, and starts a new
      collaboration session.
- [ ] Guest uses the new signed Invite with the same managed root.
- [ ] Download is staged outside Active and all chunks, Manifest, Descriptor,
      Owner signature, Publisher signature, Unity metadata, and package identity
      verify before activation.
- [ ] A new immutable `active/2-<manifest-prefix>` directory is created.
- [ ] The prior rev1 Active remains present and byte-unchanged.
- [ ] `current.json` moves atomically to the verified rev2 identity only after
      activation is complete.
- [ ] Unity opens rev2, applies the new session handoff, and realtime rejoin
      succeeds without a Scene-baseline bypass.

## D. Identity, signature, and trust negatives

- [ ] A correctly signed Invite with the prior Project ID but changed Project
      UUID hard-fails and does not create/select another Active.
- [ ] A correctly signed Invite for the same Project UUID but changed Owner
      hard-fails and leaves stored Invite, trust pin, and Active unchanged.
- [ ] A tampered Project Invite or bootstrap envelope hard-fails before network
      trust or managed-root mutation.
- [ ] A same Project/Owner rev2 signed by a changed Publisher shows the explicit
      Publisher fingerprint trust flow.
- [ ] Declining the changed Publisher leaves rev1 current and does not expose a
      rev2 Unity handoff.
- [ ] After out-of-band fingerprint verification, explicit approval permits the
      verified rev2 activation and updates only the Publisher trust pin.

## E. Failed rev2 transfer and recovery

- [ ] Interrupt or fault rev2 chunk transfer after signed Baseline discovery.
- [ ] Failure is reported and retained only as bounded staging/resumable data.
- [ ] Rev1 Active and `current.json` remain unchanged and Unity-openable.
- [ ] No partial rev2 directory appears under `active/`.
- [ ] Retrying the same valid Invite reuses verified chunks and completes rev2.
- [ ] Guest is never told to create a new managed-root folder merely because the
      session or approved Baseline revision changed.

## F. Scope and closure

- [ ] Protocol v1, Authority, direct HTTP transfer, signatures, hashes, trust,
      immutable Active, and atomic-pointer invariants show no regression.
- [ ] Arbitrary component/serialized-property synchronization remains recorded
      as the existing Known Limitation and was not treated as a WP4.1 blocker.
- [ ] No WebRTC, ICE/STUN/TURN, relay, discovery, or NAT traversal path appeared.
- [ ] Attach logs/screenshots, current-pointer hashes, Active paths, Invite
      identity fingerprints, and PASS/FAIL notes to the field record.

Overall WP4.1 field gate: PASS / FAIL / NOT RUN

WP4.1 may be called CLOSED only when every required item above passes on the
exact candidate across the two Windows PCs.
